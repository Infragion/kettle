import pygame
from pygame.locals import *
 
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
GRAY = (200, 200, 200)

pygame.init()
pygame.display.set_caption("kettle")
icon = pygame.image.load("assets/images/icon.png")
pygame.display.set_icon(icon)
screen = pygame.display.set_mode((820, 640))

font = pygame.font.Font("assets/fonts/tinos.ttf", 48)

img = font.render("a button", True, BLACK)
rect = img.get_rect()
pygame.draw.rect(img, (173, 173, 173), rect, 1)

running = True
background = GRAY

screen.fill(background)
center = img.get_rect(center = screen.get_rect().center)
temp_surface = pygame.Surface(img.get_size())
temp_surface.fill((192, 192, 192))
temp_surface.blit(img, (0, 0))
button = screen.blit(temp_surface, center)

while running:
    for event in pygame.event.get():
        if event.type == QUIT:
            running = False
        if event.type == MOUSEBUTTONDOWN:
            mouse = pygame.mouse.get_pos()
            if button.collidepoint(mouse): 
                pygame.quit()

    pygame.display.update()

pygame.quit()